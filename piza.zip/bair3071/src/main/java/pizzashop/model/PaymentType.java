package pizzashop.model;

public enum PaymentType {
    CASH, CARD
}